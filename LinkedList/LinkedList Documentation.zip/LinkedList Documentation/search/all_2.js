var searchData=
[
  ['insertfirst',['insertFirst',['../class_linked_list.html#a1946dfce2d2a1c4e9051684eab1b5156',1,'LinkedList']]],
  ['insertlast',['insertLast',['../class_linked_list.html#a198d17af17b1715eb7336d7e75272964',1,'LinkedList']]]
];
