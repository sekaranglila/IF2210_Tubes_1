var searchData=
[
  ['setnext',['setNext',['../class_node.html#ac53cb74d17df1997e438e7f34e7b43f0',1,'Node']]],
  ['setprev',['setPrev',['../class_node.html#a784746847032fb3a80e268f3427d45b5',1,'Node']]]
];
